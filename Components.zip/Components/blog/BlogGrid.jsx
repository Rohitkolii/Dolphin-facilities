"use client";

import { motion } from "framer-motion";
import { useState } from "react";
import { blogs } from "./blogData";

/* ============================================================
   BLOG GRID
============================================================ */

export default function BlogGrid() {
  // DEFAULT ONLY 3 CARDS
  const [visibleBlogs, setVisibleBlogs] = useState(3);

  const displayedBlogs = blogs.slice(0, visibleBlogs);

  const hasMore = visibleBlogs < blogs.length;

  return (
    <section
      className="
        w-full
        bg-[#303030]
        px-4
        sm:px-6
        md:px-10
        lg:px-16
        xl:px-20
        py-10
        md:py-14
        lg:py-16
        overflow-hidden
      "
    >
      {/* DESKTOP WIDER CONTAINER */}
      <div className="w-full max-w-[1500px] mx-auto">

        {/* BLOG GRID */}

        <div
          className="
            grid
            grid-cols-1
            sm:grid-cols-2
            lg:grid-cols-3
            gap-5
            md:gap-7
            lg:gap-9
          "
        >
          {displayedBlogs.map((blog, index) => (
            <BlogCard
              key={blog.id}
              blog={blog}
              index={index}
            />
          ))}
        </div>


        {/* LOAD MORE / LOAD LESS */}

        <motion.div
          initial={{
            opacity: 0,
            y: 25,
          }}
          whileInView={{
            opacity: 1,
            y: 0,
          }}
          viewport={{
            once: true,
            amount: 0.2,
          }}
          transition={{
            duration: 0.7,
            ease: [0.22, 1, 0.36, 1],
          }}
          className="
            flex
            justify-center
            mt-10
            md:mt-14
          "
        >
          {hasMore ? (
            <motion.button
              type="button"
              onClick={() =>
                setVisibleBlogs((prev) =>
                  Math.min(prev + 3, blogs.length)
                )
              }
              whileHover={{
                scale: 1.05,
                y: -2,
              }}
              whileTap={{
                scale: 0.96,
              }}
              className="
                px-7
                py-3
                min-w-[140px]
                bg-gradient-to-r
                from-[#79cba8]
                to-[#329bd0]
                border
                border-[#73c9b9]
                text-white
                text-[14px]
                md:text-[15px]
                font-medium
                cursor-pointer
                transition-all
                duration-300
                hover:brightness-110
              "
            >
              Load More
            </motion.button>
          ) : (
            visibleBlogs > 3 && (
              <motion.button
                type="button"
                onClick={() => setVisibleBlogs(3)}
                whileHover={{
                  scale: 1.05,
                  y: -2,
                }}
                whileTap={{
                  scale: 0.96,
                }}
                className="
                  px-7
                  py-3
                  min-w-[140px]
                  bg-gradient-to-r
                  from-[#79cba8]
                  to-[#329bd0]
                  border
                  border-[#73c9b9]
                  text-white
                  text-[14px]
                  md:text-[15px]
                  font-medium
                  cursor-pointer
                  transition-all
                  duration-300
                  hover:brightness-110
                "
              >
                Load Less
              </motion.button>
            )
          )}
        </motion.div>

      </div>
    </section>
  );
}


/* ============================================================
   BLOG CARD
============================================================ */

function BlogCard({ blog, index }) {
  return (
    <motion.article
      initial={{
        opacity: 0,
        y: 45,
        scale: 0.96,
      }}
      whileInView={{
        opacity: 1,
        y: 0,
        scale: 1,
      }}
      viewport={{
        once: true,
        amount: 0.15,
      }}
      transition={{
        duration: 0.7,
        delay: index * 0.08,
        ease: [0.22, 1, 0.36, 1],
      }}
      className="
        group
        relative
        aspect-square
        overflow-hidden
        border
        border-[#2999c7]
        bg-[#222]
        cursor-pointer
      "
    >
      {/* IMAGE */}

      <img
        src={blog.image}
        alt={blog.title}
        draggable="false"
        className="
          absolute
          inset-0
          w-full
          h-full
          object-cover
          transition-transform
          duration-700
          ease-[cubic-bezier(0.22,1,0.36,1)]
          group-hover:scale-[1.07]
        "
      />


      {/* DARK OVERLAY */}

      <div
        className="
          absolute
          inset-0
          bg-black/10
          group-hover:bg-black/35
          transition-all
          duration-500
        "
      />


      {/* BOTTOM GRADIENT */}

      <div
        className="
          absolute
          left-0
          right-0
          bottom-0
          h-[65%]
          bg-gradient-to-t
          from-black/95
          via-black/55
          to-transparent
        "
      />


      {/* HOVER SHINE */}

      <div
        className="
          absolute
          inset-0
          bg-gradient-to-b
          from-white/10
          via-transparent
          to-transparent
          opacity-0
          group-hover:opacity-100
          transition-opacity
          duration-500
        "
      />


      {/* CONTENT */}

      <div
        className="
          absolute
          left-0
          right-0
          bottom-0
          z-10
          p-5
          md:p-6
          lg:p-7
        "
      >
        {/* DATE */}

        <p
          className="
            text-white/90
            text-[12px]
            md:text-[14px]
            lg:text-[15px]
            font-medium
            mb-3
          "
        >
          {blog.date}
        </p>


        {/* TITLE */}

        <h2
          className="
            text-white
            text-[19px]
            md:text-[22px]
            lg:text-[24px]
            font-semibold
            leading-[1.4]
            line-clamp-3
            transition-colors
            duration-300
            group-hover:text-[#69c7d9]
          "
        >
          {blog.title}
        </h2>


        {/* READ MORE */}

        <a
          href={`/blog/${blog.id}`}
          className="
            inline-flex
            items-center
            gap-2
            mt-5
            text-white
            text-[14px]
            md:text-[15px]
            font-medium
            transition-all
            duration-300
            hover:text-[#65c5d8]
            hover:gap-3
          "
        >
          Read More

          <span
            className="
              text-[24px]
              leading-none
              transition-transform
              duration-300
            "
          >
            →
          </span>
        </a>
      </div>

    </motion.article>
  );
}